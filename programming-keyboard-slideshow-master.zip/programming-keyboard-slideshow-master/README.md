# programming-keyboard-slideshow
Reveal.js slideshow for programming your keyboard

A clone of the [reveal.js](https://github.com/hakimel/reveal.js) repository for a slideshow presentation for programming your keyboard. The slideshow can be found on GitHub Pages [here](http://bpruitt-goddard.github.io/programming-keyboard-slideshow)